const data = {
  toilet_search: {
    img: "https://z9in.github.io/myhome/images/toilet_react.jpg",
    title: "공중화장 검색",
    detales: [
      "공공데이터 활용 : 경기도 공중화장실 위치 데이터",
      "카카오 MAP API활용",
    ],
    future: [
      "추가적인 자료를 수집, 전국 기준으로 진행",
      "지역 확인 시 주소가 아닌 키워드로 검색 가능토록 방법 모색",
    ],
    github: "https://github.com/z9in/toiletSearch_react",
    site: null,
  },
  toilet_search2: {
    img: "https://z9in.github.io/myhome/images/toilet_react.jpg",
    title: "공중화장 검색",
    detales: [
      "공공데이터 활용 : 경기도 공중화장실 위치 데이터",
      "카카오 MAP API활용",
    ],
    future: [
      "추가적인 자료를 수집, 전국 기준으로 진행",
      "지역 확인 시 주소가 아닌 키워드로 검색 가능토록 방법 모색",
    ],
    github: "https://github.com/z9in/toiletSearch_react",
    site: null,
  },
};

export default { data };
