// works_List slide
import data from "./items.js";

const left_handleEl = document.getElementsByClassName("left_handle")[0];
const right_handleEl = document.getElementsByClassName("right_handle")[0];
const slateEl = document.getElementsByClassName("slate")[0];
const itemEls = document.querySelectorAll(".item");
let num = 0;
left_handleEl.addEventListener("click", () => {
  if (num > -1) {
    alert("처음입니다.");
  } else {
    num = num + 465;
    slateEl.style.transform = `translateX(${num}px)`;
  }
});
right_handleEl.addEventListener("click", () => {
  if (num < -((itemEls.length - 3) * 465)) {
    alert("마지막입니다.");
  } else {
    num = num - 465;
    slateEl.style.transform = `translateX(${num}px)`;
  }
});

// screen에 보여 주기
console.log(data.Prototype());
// console.log(itemEls);
itemEls.forEach((e) => [
  e.addEventListener("click", () => {
    let index = e.children[0].alt;
    console.log(typeOf(data));
  }),
]);
